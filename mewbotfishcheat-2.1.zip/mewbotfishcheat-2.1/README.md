# mewbotfishcheat
simple codes to get answers in mewbot fishing
